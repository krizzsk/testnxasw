void function() {
  

  

  

  Foundation && Foundation.refreshDDConfig && Foundation.refreshDDConfig({
  "pages": [
    "pages/index",
    "pages/webview",
    "pages/bill/payDetail",
    "pages/bill/list",
    "pages/giftcard/package-list",
    "pages/giftcard/card-list",
    "pages/giftcard/detail",
    "pages/giftcard/index"
  ],
  "global": {
    "window": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show"
    }
  },
  "subpackagesDir": {
    "__APP__": "app"
  },
  "subpackages": [],
  "subPackages": [],
  "entryPagePath": "pages/index",
  "page": {
    "pages/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexf9d386be/index"
      }
    },
    "pages/webview": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {}
    },
    "pages/bill/payDetail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexf9d386be/index",
        "bill-popup": "/components/bill-popup8a4b738a/index",
        "bill-button": "/components/bill-button2a57bc31/index",
        "bill-toast": "/components/bill-toast21859394/index",
        "bill-popup-bottom": "/components/bill-popup-bottom330df86b/index",
        "bill-circle-loading": "/components/bill-circle-loading37098084/index",
        "van-icon": "/components/vant/weapp7238bca6/icon/index",
        "bill-activity-popup": "/components/bill-activity-popup3eb90f6d/index"
      }
    },
    "pages/bill/list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/listc3755afa/index",
        "bill-list-card": "/components/bill-list-card8df38224/index",
        "bill-list-tab": "/components/bill-list-tab1cedf2e5/index",
        "bill-toast": "/components/bill-toast21859394/index",
        "bill-popup-bottom": "/components/bill-popup-bottom330df86b/index",
        "bill-picker": "/components/bill-picker7f7ae0e6/index",
        "bill-list-cell": "/components/bill-list-cellfa5a5780/index",
        "bill-bebeing": "/components/bill-bebeing1ea871eb/index"
      }
    },
    "pages/giftcard/package-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexf9d386be/index",
        "package-cell": "/components/package-cell0290de97/index",
        "van-icon": "/components/vant/weapp7238bca6/icon/index",
        "price-popup": "/components/price-popup5f23ea48/index",
        "bill-popup-bottom": "/components/bill-popup-bottom330df86b/index",
        "bill-circle-loading": "/components/bill-circle-loading37098084/index",
        "info-entry-popup": "/components/info-entry-popup08f6a500/index",
        "package-questions": "/components/package-questions06bfca92/index",
        "faq-title": "/components/faq-titleeba9cb26/index",
        "mpx-ibg-loading": "/components/ibg-loading90e68d06/index"
      }
    },
    "pages/giftcard/card-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/listc3755afa/index",
        "bill-bebeing": "/components/bill-bebeing1ea871eb/index"
      }
    },
    "pages/giftcard/detail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-sticky": "/components/vant/dist/sticky/index",
        "bill-toast": "/components/bill-toast21859394/index",
        "van-icon": "/components/vant/weapp7238bca6/icon/index",
        "nav-bar": "/components/indexf9d386be/index"
      }
    },
    "pages/giftcard/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "layout-list": "/components/listc3755afa/index",
        "gift-card-tips": "/components/gift-card-tips09b09a46/index",
        "bill-popup-bottom": "/components/bill-popup-bottom330df86b/index",
        "van-icon": "/components/vant/weapp7238bca6/icon/index",
        "api-loading": "/components/api-loading1fd87b29/index"
      }
    }
  }
});

}();
