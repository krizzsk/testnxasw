void function() {
  

  

  

  Foundation && Foundation.refreshDDConfig && Foundation.refreshDDConfig({
  "pages": [
    "pages/index",
    "pages/example",
    "pages/bill/barcode",
    "pages/bill/payInfo",
    "pages/webview",
    "pages/bill/index",
    "pages/bill/amount",
    "pages/bill/search",
    "pages/bill/payDetail",
    "pages/bill/list",
    "pages/recharge/index",
    "pages/recharge/carrier",
    "pages/giftcard/index",
    "pages/recharge/packagelist",
    "pages/giftcard/card-list",
    "pages/giftcard/detail",
    "pages/giftcard/package-list"
  ],
  "global": {
    "window": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show"
    }
  },
  "subpackagesDir": {
    "__APP__": "app"
  },
  "subpackages": [],
  "subPackages": [],
  "entryPagePath": "pages/index",
  "page": {
    "pages/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index"
      }
    },
    "pages/example": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "list": "/components/list68c561f7/index",
        "vant-test": "/components/vant-testc813d8ba/index",
        "store-test": "/components/store-test538dfdd7/index",
        "i18n-test": "/components/i18n-test27ed3c54/index",
        "webview-test": "/components/webview-test0f53593f/index",
        "xfetch-test": "/components/xfetch-test7b6affb2/index",
        "request-test": "/components/requestb6039bf8/index",
        "bridge-test": "/components/bridge07f7aa3c/index",
        "bill-picker-test": "/components/bill-picker-test3583c184/index"
      }
    },
    "pages/bill/barcode": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-popup": "/components/bill-popup6a5a732e/index",
        "bill-button": "/components/bill-button6add2d9e/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "bill-progress": "/components/bill-progress59e89dd9/index",
        "bill-history-scroll": "/components/bill-history-scroll1f175592/index",
        "bill-barcode-popup-bottom": "/components/bill-barcode-popup-bottom57c24676/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index"
      }
    },
    "pages/bill/payInfo": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-image": "/components/bill-image5abcbc5d/index",
        "bill-button": "/components/bill-button6add2d9e/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "bill-coupon-card": "/components/bill-coupon-card67b26dce/index",
        "package-questions": "/components/package-questions936d56f6/index"
      }
    },
    "pages/webview": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {}
    },
    "pages/bill/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "bill-search": "/components/bill-search2b254114/index",
        "bill-category": "/components/bill-category488ac82a/index",
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-nav-history": "/components/bill-nav-history8f9d0da8/index",
        "van-notice-bar": "/components/vant/weapp05bd39c0/notice-bar/index"
      }
    },
    "pages/bill/amount": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "van-field": "/components/vant/weapp05bd39c0/field/index",
        "bill-button": "/components/bill-button6add2d9e/index"
      }
    },
    "pages/bill/search": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "bill-cell": "/components/bill-cell30f47d0e/index",
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-bebeing": "/components/bill-bebeing225da3c4/index",
        "bill-recommend": "/components/bill-recommend732ef5be/index"
      }
    },
    "pages/bill/payDetail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-popup": "/components/bill-popup6a5a732e/index",
        "bill-button": "/components/bill-button6add2d9e/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "bill-circle-loading": "/components/bill-circle-loading2622f42b/index",
        "bill-activity-popup": "/components/bill-activity-popupff3e784c/index",
        "package-questions": "/components/package-questions936d56f6/index"
      }
    },
    "pages/bill/list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list3c188336/index",
        "bill-list-card": "/components/bill-list-card21f0ba61/index",
        "bill-list-tab": "/components/bill-list-tab51dcbd12/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "bill-picker": "/components/bill-picker00c800fa/index",
        "bill-list-cell": "/components/bill-list-cell2885609a/index",
        "bill-bebeing": "/components/bill-bebeing225da3c4/index"
      }
    },
    "pages/recharge/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-button": "/components/vant-weapp27f0c1f3/button/index",
        "van-overlay": "/components/vant/weapp05bd39c0/overlay/index",
        "van-field": "/components/vant-weapp27f0c1f3/field/index",
        "van-cell-group": "/components/vant-weapp27f0c1f3/cell-group/index",
        "van-toast": "/components/vant-weapp27f0c1f3/toast/index",
        "nav-bar": "/components/indexc0adbb64/index",
        "type-list": "/components/type-list6ffab5d7/index",
        "phone-input": "/components/phone-input5e1a6c71/index",
        "bill-button": "/components/bill-buttonb0863204/index"
      }
    },
    "pages/recharge/carrier": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "layout-list": "/components/list3c188336/index"
      }
    },
    "pages/giftcard/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "layout-list": "/components/list3c188336/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "api-loading": "/components/api-loading578523d4/index"
      }
    },
    "pages/recharge/packagelist": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "popup-bottom": "/components/popup-bottom3c086cd8/index",
        "package-list-cell": "/components/package-list-cell6f778120/index",
        "package-questions": "/components/package-questions936d56f6/index",
        "bill-button": "/components/bill-buttonb0863204/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "faq-title": "/components/faq-title39ab4760/index"
      }
    },
    "pages/giftcard/card-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list3c188336/index",
        "bill-bebeing": "/components/bill-bebeing225da3c4/index"
      }
    },
    "pages/giftcard/detail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-sticky": "/components/vant/dist/sticky/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "nav-bar": "/components/indexc0adbb64/index",
        "package-questions": "/components/package-questions936d56f6/index"
      }
    },
    "pages/giftcard/package-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "package-cell": "/components/package-cell4a6b6d6c/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "price-popup": "/components/price-popup1388dd35/index",
        "bill-circle-loading": "/components/bill-circle-loading2622f42b/index",
        "package-questions": "/components/package-questions936d56f6/index",
        "faq-title": "/components/faq-title39ab4760/index"
      }
    }
  }
});

}();
