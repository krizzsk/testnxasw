// v1.4.2 Fix some compilation problems And Add parse exception info
if(typeof global === 'undefined') global={};
var __WXML_GLOBAL__ = {
  modules: {},
  ops_cached: {},
  ops_set: {},
  ops_init: {}
}

var $gdmc;

var $gaic={};

function _(a, b) 
{
typeof (b) != 'undefined' && a.children.push(b);
}

function _v(k) 
{
if (typeof (k) != 'undefined') return { tag: 'virtual', 'wxKey': k, children: [] };
return { tag: 'virtual', children: [] };
}

function _n(tag) 
{
return { tag: 'dd-' + tag, attr: {}, children: [], n: [], raw: {}, generics: {} }
}

function _p(a, b) 
{
b && a.properities.push(b);
}

function _s(scope, env, key) 
{
return typeof (scope[key]) != 'undefined' ? scope[key] : env[key]
}

function _wp(m) 
{
console.warn("DDMLRT_$gdm:" + m)
}

function _wl(tag_name, prefix) 
{
_wp(prefix + ':-1:-1:-1: Template `' + tag_name + '` is being called recursively, will be stop.');
}

var $gwn=console.warn;

var $gwl=console.log;

function _af(p, a, c) 
{
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _gv() 
{
return __webview_engine_version__ || 0.0
}
function $gwh() 
{

}

$gwh.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
};
var wh=new $gwh;
function $gstack(stack) 
{
var tmp=stack.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');

}

function $gwrt(should_pass_type_info) 
{
function ArithmeticEv(ops, e, s, g, o) 
{
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
}
function rev(ops, e, s, g, o, newap) 
{
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
case 4: 
return rev( ops[1], e, s, g, o, _f );
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
case 1: 
return [];
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
{
return merge( _a, _b, _ow );
}
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
}
function wrapper(ops, e, s, g, o, newap) 
{
return g.debugInfo = null, rev( ops, e, s, g, o, newap );
}
return wrapper;
}

var gra=$gwrt(true);

var grb=$gwrt(false);

function dm_for(to_iter, func, env, _s, global, father, itemname, indexname, keyname) 
{
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}
}

function _ca(o) 
{
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}

function _da(node, attrname, opindex, raw, o) 
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function )
{
attrname = "$wxs:" + attrname;
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) )
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}

function _r(node, attrname, opindex, env, scope, global) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}

function _rz(z, node, attrname, opindex, env, scope, global) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}

function _o(opindex, env, scope, global) 
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}

function _oz(z, opindex, env, scope, global) 
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}

function _1(opindex, env, scope, global, o) 
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}

function _1z(z, opindex, env, scope, global, o) 
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}

function _2(opindex, func, env, scope, global, father, itemname, indexname, keyname) 
{
var to_iter = _1( opindex, env, scope, global );
dm_for( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}

function _2z(z, opindex, func, env, scope, global, father, itemname, indexname, keyname) 
{
var to_iter = _1z(z, opindex, env, scope, global );
dm_for( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}

function _m(tag, attrs, generics, env, scope, global) 
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="dd-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

function _mz(z, tag, attrs, generics, env, scope, global) 
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="dd-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}

var getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));};

var getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
function _ai(i, p, e, me, r, c) 
{
i.push(p);
}

function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}

function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}

var $ixc={};

function _ic(p,ent,me,e,s,r,gg){var x=p;ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}

function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

function _ev(dom) 
{
var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom;
}

var e_={};
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={};
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={};
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={};
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {};
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gdm || []
__WXML_GLOBAL__.ops_set.$gdm = z;
__WXML_GLOBAL__.ops_init.$gdm = true;;
var x = ['pages/giftcard/package-list.wxml','components/faq-title39ab4760/index.wxml','components/package-questions936d56f6/index.wxml','components/bill-circle-loading2622f42b/index.wxml','components/vant-weapp27f0c1f3/loading/index.wxml','components/vant-weapp27f0c1f3/button/index.wxml','components/vant-weapp27f0c1f3/cell-group/index.wxml','components/vant-weapp27f0c1f3/cell/index.wxml','components/vant-weapp27f0c1f3/field/index.wxml','components/vant/weapp05bd39c0/transition/index.wxml','components/vant/weapp05bd39c0/overlay/index.wxml','components/price-popup1388dd35/index.wxml','components/vant/weapp05bd39c0/info/index.wxml','components/vant/weapp05bd39c0/icon/index.wxml','components/package-cell4a6b6d6c/index.wxml','components/vant/dist/sticky/index.wxml','components/vant-weapp27f0c1f3/info/index.wxml','components/vant-weapp27f0c1f3/icon/index.wxml','components/indexc0adbb64/index.wxml'];
function gz$gdm_0(){
if( __WXML_GLOBAL__.ops_cached.$gdm_0)return __WXML_GLOBAL__.ops_cached.$gdm_0
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_0=[
[3,'package-list'],
[3,'backBtn'],
[1,true],
[1,true],
[[7],[3,'navTitle']],
[1,true],
[3,'package-list-head'],
[3,'package-list-head-text'],
[3,'name'],
[a,[[6],[[7],[3,'giftCardDetail']],[3,'billerName']]],
[a,[[6],[[7],[3,'giftCardDetail']],[3,'billerDesc']]],
[3,'package-list-head-img'],
[3,'heightFix'],
[[6],[[7],[3,'giftCardDetail']],[3,'billerIcon']],
[3,'package-list-content'],
[3,'collapseCellTitle'],
[a,[[7],[3,'_i1']]],
[3,'index'],
[3,'item'],
[[6],[[7],[3,'giftCardDetail']],[3,'merchantList']],
[[2,'==='],[[7],[3,'selectItemIndex']],[[7],[3,'index']]],
[3,'__invoke'],
[[7],[3,'item']],
[[8],'tap',[[4],[[5],[[4],[[5],[[5],[[5],[1,'cellTap']],[[7],[3,'index']]],[[7],[3,'item']]]]]]],
[[7],[3,'giftCardDetailVolatileMerchant']],
[[2,'==='],[[7],[3,'selectItemIndex']],[1,'custom']],
[3,'__invoke'],
[[7],[3,'customMonny']],
[1,true],
[[7],[3,'customTypeCashback']],
[[8],'tap',[[4],[[5],[[4],[[5],[[5],[1,'cellTap']],[1,'custom']]]]]],
[3,'faq-questions'],
[[2,'>'],[[7],[3,'isShowFaqList']],[1,1]],
[[2,'>'],[[7],[3,'isShowFaqList']],[1,1]],
[[7],[3,'_i2']],
[3,'index'],
[3,'item'],
[[2,'&&'],[[2,'>'],[[7],[3,'isShowFaqList']],[1,0]],[[6],[[7],[3,'giftCardDetail']],[3,'faqArray']]],
[3,'changeFold'],
[[7],[3,'index']],
[[7],[3,'item']],
[1,true],
[3,'package-list-pay'],
[[7],[3,'hasCouponStatus']],
[3,'package-list-pay-voucher'],
[3,'package-list-pay-voucher-title'],
[3,'https://img0.didiglobal.com/static/gstar/img/xU3Ay4db8b1651756290314.png'],
[a,[[7],[3,'_i3']]],
[3,'couponMore'],
[3,'package-list-pay-voucher-num'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyClass']],[[5],[[5],[1,'']],[[2,'?:'],[[7],[3,'conpunApiLoading']],[1,'package-list-pay-voucher-num-text'],[1,'']]]],
[a,[[7],[3,'couponText']]],
[3,'arrow'],
[3,'color: #dcddde'],
[3,'payTap'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyClass']],[[5],[[5],[1,'package-list-pay-btn']],[[2,'?:'],[[7],[3,'giftCardPrice']],[1,'payStatus'],[1,'']]]],
[a,[[7],[3,'_i4']]],
[3,'onClose'],
[3,'setCustomPrice'],
[[7],[3,'checkMerchant']],
[[7],[3,'totalAmountFe']],
[[7],[3,'popupShow']],
[3,'overLoad'],
[[7],[3,'checkData']],
[[7],[3,'loadingTime']],
[[7],[3,'loadingShowBL']]
];
return __WXML_GLOBAL__.ops_cached.$gdm_0}
d_[x[0]]={};
function m0(e,s,r,gg){
var z = gz$gdm_0();
var $0=_n('view');
_rz(z,$0,'class',0,e,s,gg);
var $1=_mz(z,'nav-bar',['bindbackBtn',1,'customBackBtn',1,'isShowBack',2,'navTitle',3,'navTransparent',4],[],e,s,gg);
_($0,$1);
var $2=_n('view');
_rz(z,$2,'class',6,e,s,gg);
var $3=_n('view');
_rz(z,$3,'class',7,e,s,gg);
var $4=_n('view');
_rz(z,$4,'class',8,e,s,gg);
var $$9=_oz(z,9,e,s,gg);
_($4,$$9);
_($3,$4);
var $6=_n('view');
var $$10=_oz(z,10,e,s,gg);
_($6,$$10);
_($3,$6);
_($2,$3);
var $8=_n('view');
_rz(z,$8,'class',11,e,s,gg);
var $9=_mz(z,'image',['mode',12,'src',1],[],e,s,gg);
_($8,$9);
_($2,$8);
_($0,$2);
var $10=_n('view');
_rz(z,$10,'class',14,e,s,gg);
var $11=_n('view');
_rz(z,$11,'class',15,e,s,gg);
var $$16=_oz(z,16,e,s,gg);
_($11,$$16);
_($10,$11);
var $13_vf=_v();
_($10,$13_vf);
var $13_for = function(ef,sf,rf,ggf){
var $13=_mz(z,'package-cell',['active',20,'bindtap',1,'cardData',2,'data-eventconfigs',3],[],ef,sf,ggf);
_(rf, $13);
return rf;
}
$13_vf.wxXCkey=4;
_2z(z,19,$13_for,e,s,gg,$13_vf, 'item','index','');
var $14_vc=_v();
_($10,$14_vc);
if(_oz(z,24,e,s,gg)){$14_vc.wxVkey=1
var $14=_mz(z,'package-cell',['active',25,'bindtap',1,'cardData',2,'customType',3,'customTypeCashback',4,'data-eventconfigs',5],[],e,s,gg);
_($14_vc,$14);
}
var $15=_n('view');
_rz(z,$15,'class',31,e,s,gg);
var $16_vc=_v();
_($15,$16_vc);
if(_oz(z,32,e,s,gg)){$16_vc.wxVkey=1
var $16=_mz(z,'faq-title',['isShow',33,'text',1],[],e,s,gg);
_($16_vc,$16);
}
var $17_vf=_v();
_($15,$17_vf);
var $17_for = function(ef,sf,rf,ggf){
var $17=_mz(z,'package-questions',['bindchangeFold',38,'index',1,'questionAnswer',2,'showTitle',3],[],ef,sf,ggf);
_(rf, $17);
return rf;
}
$17_vf.wxXCkey=4;
_2z(z,37,$17_for,e,s,gg,$17_vf, 'item','index','');
$16_vc.wxXCkey=3;
_($10,$15);
$14_vc.wxXCkey=3;
_($0,$10);
var $18=_n('view');
_rz(z,$18,'class',42,e,s,gg);
var $19_vc=_v();
_($18,$19_vc);
if(_oz(z,43,e,s,gg)){$19_vc.wxVkey=1
var $19=_n('view');
_rz(z,$19,'class',44,e,s,gg);
var $20=_n('view');
_rz(z,$20,'class',45,e,s,gg);
var $21=_n('image');
_rz(z,$21,'src',46,e,s,gg);
_($20,$21);
var $22=_n('view');
var $$47=_oz(z,47,e,s,gg);
_($22,$$47);
_($20,$22);
_($19,$20);
var $24=_mz(z,'view',['bindtap',48,'class',1],[],e,s,gg);
var $25=_n('view');
_rz(z,$25,'class',50,e,s,gg);
var $$51=_oz(z,51,e,s,gg);
_($25,$$51);
_($24,$25);
var $27=_mz(z,'van-icon',['name',52,'style',1],[],e,s,gg);
_($24,$27);
_($19,$24);
_($19_vc,$19);
}
var $28=_mz(z,'view',['bindtap',54,'class',1],[],e,s,gg);
var $$56=_oz(z,56,e,s,gg);
_($28,$$56);
_($18,$28);
$19_vc.wxXCkey=3;
_($0,$18);
var $30=_mz(z,'price-popup',['bindonClose',57,'bindsetCustomPrice',1,'checkMerchant',2,'customPrice',3,'show',4],[],e,s,gg);
_($0,$30);
var $31=_mz(z,'bill-circle-loading',['bindoverLoad',62,'checkData',1,'loadingTime',2,'show',3],[],e,s,gg);
_($0,$31);
_(r,$0);
return r;
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
function gz$gdm_1(){
if( __WXML_GLOBAL__.ops_cached.$gdm_1)return __WXML_GLOBAL__.ops_cached.$gdm_1
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_1=[
[[2,'&&'],[[2,'!=='],[[7],[3,'text']],[1,'undefined']],[[7],[3,'isShow']]],
[3,'title'],
[a,[[7],[3,'text']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_1}
d_[x[1]]={};
function m1(e,s,r,gg){
var z = gz$gdm_1();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_n('view');
_rz(z,$0,'class',1,e,s,gg);
var $$2=_oz(z,2,e,s,gg);
_($0,$$2);
_($0_vc,$0);
}
$0_vc.wxXCkey=1;
return r;
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
function gz$gdm_2(){
if( __WXML_GLOBAL__.ops_cached.$gdm_2)return __WXML_GLOBAL__.ops_cached.$gdm_2
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_2=[
[[7],[3,'showTitle']],
[3,'faq-body'],
[3,'btnTap'],
[3,'faq-body-questions'],
[3,'faq-body-questions-title'],
[a,[[7],[3,'questions']]],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyClass']],[[5],[[5],[1,'faq-body-questions-icon']],[[2,'?:'],[[7],[3,'isFold']],[1,''],[1,'faq-body-questions-transformUp']]]],
[[2,'?:'],[[7],[3,'isFold']],[1,'arrow-down'],[1,'arrow-up']],
[3,'faq-body-answers'],
[[2,'?:'],[[2,'||'],[[2,'!'],[[7],[3,'isFold']]],[[2,'==='],[[2,'!'],[[7],[3,'isFold']]],[1,undefined]]],[1,''],[1,'display:none;']],
[a,[[7],[3,'answers']]],
[3,'faq-body-cancel'],
[3,'btnTap'],
[3,'faq-body-cancel-questions'],
[3,'faq-body-cancel-questions-title'],
[a,[[7],[3,'questions']]],
[3,'faq-body-cancel-questions-icon'],
[[2,'?:'],[[7],[3,'isFold']],[1,'arrow-down'],[1,'arrow-up']],
[a,[3,'color: '],[1,'#333333']],
[[2,'!'],[[7],[3,'isFold']]],
[3,'faq-body-cancel-answers'],
[a,[[7],[3,'answers']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_2}
d_[x[2]]={};
function m2(e,s,r,gg){
var z = gz$gdm_2();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_n('view');
_rz(z,$0,'class',1,e,s,gg);
var $1=_mz(z,'view',['bindtap',2,'class',1],[],e,s,gg);
var $2=_n('view');
_rz(z,$2,'class',4,e,s,gg);
var $3=_n('view');
var $$5=_oz(z,5,e,s,gg);
_($3,$$5);
_($2,$3);
_($1,$2);
var $5=_n('view');
_rz(z,$5,'class',6,e,s,gg);
var $6=_n('van-icon');
_rz(z,$6,'name',7,e,s,gg);
_($5,$6);
_($1,$5);
_($0,$1);
var $7=_mz(z,'view',['class',8,'style',1],[],e,s,gg);
var $$10=_oz(z,10,e,s,gg);
_($7,$$10);
_($0,$7);
_($0_vc,$0);
}
else{$0_vc.wxVkey=2
var $9=_n('view');
_rz(z,$9,'class',11,e,s,gg);
var $10=_mz(z,'view',['bindtap',12,'class',1],[],e,s,gg);
var $11=_n('view');
_rz(z,$11,'class',14,e,s,gg);
var $$15=_oz(z,15,e,s,gg);
_($11,$$15);
_($10,$11);
var $13=_mz(z,'van-icon',['class',16,'name',1,'style',2],[],e,s,gg);
_($10,$13);
_($9,$10);
var $14_vc=_v();
_($9,$14_vc);
if(_oz(z,19,e,s,gg)){$14_vc.wxVkey=1
var $14=_n('view');
_rz(z,$14,'class',20,e,s,gg);
var $$21=_oz(z,21,e,s,gg);
_($14,$$21);
_($14_vc,$14);
}
$14_vc.wxXCkey=1;
_($0_vc,$9);
}
$0_vc.wxXCkey=3;
$0_vc.wxXCkey=3;
return r;
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
function gz$gdm_3(){
if( __WXML_GLOBAL__.ops_cached.$gdm_3)return __WXML_GLOBAL__.ops_cached.$gdm_3
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_3=[
[[7],[3,'loadingShow']],
[3,'circle-loading'],
[3,'circle-loading-timer'],
[a,[[2,'+'],[[7],[3,'time']],[1,'S']]],
[3,'circle-loading-title'],
[a,[[7],[3,'_i1']]],
[3,'circle-loading-desc'],
[a,[[7],[3,'_i2']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_3}
d_[x[3]]={};
function m3(e,s,r,gg){
var z = gz$gdm_3();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_n('view');
_rz(z,$0,'class',1,e,s,gg);
var $1=_n('view');
_rz(z,$1,'class',2,e,s,gg);
var $$3=_oz(z,3,e,s,gg);
_($1,$$3);
_($0,$1);
var $3=_n('view');
_rz(z,$3,'class',4,e,s,gg);
var $$5=_oz(z,5,e,s,gg);
_($3,$$5);
_($0,$3);
var $5=_n('view');
_rz(z,$5,'class',6,e,s,gg);
var $$7=_oz(z,7,e,s,gg);
_($5,$$7);
_($0,$5);
_($0_vc,$0);
}
$0_vc.wxXCkey=1;
return r;
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
function gz$gdm_4(){
if( __WXML_GLOBAL__.ops_cached.$gdm_4)return __WXML_GLOBAL__.ops_cached.$gdm_4
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_4=[
[3,'van-loading custom-class'],
[a,[3,'width: '],[[7],[3,'size']],[3,'; height: '],[[7],[3,'size']]],
[a,[3,'van-loading__spinner van-loading__spinner--'],[[7],[3,'type']]],
[a,[3,'color: '],[[7],[3,'color']],[3,';']],
[3,'item in 12'],
[3,'index'],
[[2,'==='],[[7],[3,'type']],[1,'spinner']],
[3,'van-loading__dot']
];
return __WXML_GLOBAL__.ops_cached.$gdm_4}
d_[x[4]]={};
function m4(e,s,r,gg){
var z = gz$gdm_4();
var $0=_mz(z,'view',['class',0,'style',1],[],e,s,gg);
var $1=_mz(z,'view',['class',2,'style',1],[],e,s,gg);
var $2_vf=_v();
_($1,$2_vf);
var $2_for = function(ef,sf,rf,ggf){
var $2_vc=_v();
_(rf,$2_vc);
if(_oz(z,6,ef,sf,ggf)){$2_vc.wxVkey=1
var $2=_n('view');
_rz(z,$2,'class',7,ef,sf,ggf);
_($2_vc,$2);
}
$2_vc.wxXCkey=1;
return rf;
}
$2_vf.wxXCkey=2;
_2z(z,4,$2_for,e,s,gg,$2_vf, 'item','index','index');
_($0,$1);
_(r,$0);
return r;
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
function gz$gdm_5(){
if( __WXML_GLOBAL__.ops_cached.$gdm_5)return __WXML_GLOBAL__.ops_cached.$gdm_5
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_5=[
[[7],[3,'appParameter']],
[[7],[3,'ariaLabel']],
[3,'bindContact'],
[3,'bindError'],
[3,'bindGetPhoneNumber'],
[3,'bindGetUserInfo'],
[3,'bindLaunchApp'],
[3,'bindOpenSetting'],
[3,'onClick'],
[[7],[3,'businessId']],
[a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'button']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[8],'block',[[7],[3,'block']]],[[8],'round',[[7],[3,'round']]]],[[8],'plain',[[7],[3,'plain']]]],[[8],'square',[[7],[3,'square']]]],[[8],'loading',[[7],[3,'loading']]]],[[8],'disabled',[[7],[3,'disabled']]]],[[8],'hairline',[[7],[3,'hairline']]]],[[8],'unclickable',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'hairline']],[1,'van-hairline--surround'],[1,'']]],
[3,'van-button--active hover-class'],
[[7],[3,'id']],
[[7],[3,'lang']],
[[7],[3,'openType']],
[[7],[3,'sendMessageImg']],
[[7],[3,'sendMessagePath']],
[[7],[3,'sendMessageTitle']],
[[7],[3,'sessionFrom']],
[[7],[3,'showMessageCard']],
[[2,'?:'],[[7],[3,'color']],[[2,'+'],[[2,'+'],[[2,'+'],[1,'border-color: '],[[7],[3,'color']]],[1,';']],[[2,'?:'],[[7],[3,'plain']],[[2,'+'],[1,'color: '],[[7],[3,'color']]],[[2,'+'],[1,'color: #fff; background-color: '],[[7],[3,'color']]]]],[1,'']],
[[7],[3,'loading']],
[[2,'?:'],[[2,'==='],[[7],[3,'type']],[1,'default']],[1,'#c9c9c9'],[1,'']],
[3,'loading-class'],
[[7],[3,'loadingSize']],
[[7],[3,'loadingText']],
[3,'van-button__loading-text'],
[a,[[7],[3,'loadingText']]],
[[7],[3,'icon']],
[3,'van-button__icon'],
[3,'line-height: inherit;'],
[[7],[3,'icon']],
[3,'1.2em'],
[3,'van-button__text']
];
return __WXML_GLOBAL__.ops_cached.$gdm_5}
d_[x[5]]={};
function m5(e,s,r,gg){
var z = gz$gdm_5();
var $0=_mz(z,'button',['appParameter',0,'ariaLabel',1,'bindcontact',1,'binderror',2,'bindgetphonenumber',3,'bindgetuserinfo',4,'bindlaunchapp',5,'bindopensetting',6,'bindtap',7,'businessId',8,'class',9,'hoverClass',10,'id',11,'lang',12,'openType',13,'sendMessageImg',14,'sendMessagePath',15,'sendMessageTitle',16,'sessionFrom',17,'showMessageCard',18,'style',19],[],e,s,gg);
var $1_vc=_v();
_($0,$1_vc);
if(_oz(z,21,e,s,gg)){$1_vc.wxVkey=1
var $2=_mz(z,'van-loading',['color',22,'customClass',1,'size',2],[],e,s,gg);
_($1_vc,$2);
var $3_vc=_v();
_($1_vc,$3_vc);
if(_oz(z,25,e,s,gg)){$3_vc.wxVkey=1
var $3=_n('view');
_rz(z,$3,'class',26,e,s,gg);
var $$27=_oz(z,27,e,s,gg);
_($3,$$27);
_($3_vc,$3);
}
$3_vc.wxXCkey=1;
}
else{$1_vc.wxVkey=2
var $6_vc=_v();
_($1_vc,$6_vc);
if(_oz(z,28,e,s,gg)){$6_vc.wxVkey=1
var $6=_mz(z,'van-icon',['class',29,'customStyle',1,'name',2,'size',3],[],e,s,gg);
_($6_vc,$6);
}
var $7=_n('view');
_rz(z,$7,'class',33,e,s,gg);
var $8=_n('slot');
_($7,$8);
_($1_vc,$7);
$6_vc.wxXCkey=3;
}
$1_vc.wxXCkey=3;
$1_vc.wxXCkey=3;
_(r,$0);
return r;
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
function gz$gdm_6(){
if( __WXML_GLOBAL__.ops_cached.$gdm_6)return __WXML_GLOBAL__.ops_cached.$gdm_6
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_6=[
[[7],[3,'title']],
[3,'van-cell-group__title'],
[a,[[7],[3,'title']]],
[a,[3,'custom-class van-cell-group '],[[2,'?:'],[[7],[3,'border']],[1,'van-hairline--top-bottom'],[1,'']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_6}
d_[x[6]]={};
function m6(e,s,r,gg){
var z = gz$gdm_6();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_n('view');
_rz(z,$0,'class',1,e,s,gg);
var $$2=_oz(z,2,e,s,gg);
_($0,$$2);
_($0_vc,$0);
}
var $2=_n('view');
_rz(z,$2,'class',3,e,s,gg);
var $3=_n('slot');
_($2,$3);
_(r,$2);
$0_vc.wxXCkey=1;
return r;
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
function gz$gdm_7(){
if( __WXML_GLOBAL__.ops_cached.$gdm_7)return __WXML_GLOBAL__.ops_cached.$gdm_7
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_7=[
[3,'onClick'],
[a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'cell']],[[4],[[5],[[5],[[7],[3,'size']]],[[9],[[9],[[9],[[8],'center',[[7],[3,'center']]],[[8],'required',[[7],[3,'required']]]],[[8],'borderless',[[2,'!'],[[7],[3,'border']]]]],[[8],'clickable',[[2,'||'],[[7],[3,'isLink']],[[7],[3,'clickable']]]]]]]]]],
[3,'van-cell--hover hover-class'],
[3,'70'],
[[7],[3,'customStyle']],
[[7],[3,'icon']],
[3,'van-cell__left-icon-wrap'],
[3,'van-cell__left-icon'],
[[7],[3,'icon']],
[3,'icon'],
[3,'van-cell__title title-class'],
[[2,'?:'],[[7],[3,'titleWidth']],[[2,'+'],[[2,'+'],[[2,'+'],[1,'max-width:'],[[7],[3,'titleWidth']]],[1,';min-width:']],[[7],[3,'titleWidth']]],[1,'']],
[[7],[3,'title']],
[a,[[7],[3,'title']]],
[3,'title'],
[[2,'||'],[[7],[3,'label']],[[7],[3,'useLabelSlot']]],
[3,'van-cell__label label-class'],
[[7],[3,'useLabelSlot']],
[3,'label'],
[[7],[3,'label']],
[a,[[7],[3,'label']]],
[3,'van-cell__value value-class'],
[[2,'||'],[[7],[3,'value']],[[2,'==='],[[7],[3,'value']],[1,0]]],
[a,[[7],[3,'value']]],
[[7],[3,'isLink']],
[3,'van-cell__right-icon-wrap right-icon-class'],
[3,'van-cell__right-icon'],
[[2,'?:'],[[7],[3,'arrowDirection']],[[2,'+'],[[2,'+'],[1,'arrow'],[1,'-']],[[7],[3,'arrowDirection']]],[1,'arrow']],
[3,'right-icon'],
[3,'extra']
];
return __WXML_GLOBAL__.ops_cached.$gdm_7}
d_[x[7]]={};
function m7(e,s,r,gg){
var z = gz$gdm_7();
var $0=_mz(z,'view',['bind:tap',0,'class',1,'hoverClass',1,'hoverStayTime',2,'style',3],[],e,s,gg);
var $1_vc=_v();
_($0,$1_vc);
if(_oz(z,5,e,s,gg)){$1_vc.wxVkey=1
var $1=_mz(z,'van-icon',['class',6,'customClass',1,'name',2],[],e,s,gg);
_($1_vc,$1);
}
else{$1_vc.wxVkey=2
var $2=_n('slot');
_rz(z,$2,'name',9,e,s,gg);
_($1_vc,$2);
}
var $3=_mz(z,'view',['class',10,'style',1],[],e,s,gg);
var $4_vc=_v();
_($3,$4_vc);
if(_oz(z,12,e,s,gg)){$4_vc.wxVkey=1
var $$13=_oz(z,13,e,s,gg);
_($4_vc,$$13);
}
else{$4_vc.wxVkey=2
var $6=_n('slot');
_rz(z,$6,'name',14,e,s,gg);
_($4_vc,$6);
}
var $7_vc=_v();
_($3,$7_vc);
if(_oz(z,15,e,s,gg)){$7_vc.wxVkey=1
var $7=_n('view');
_rz(z,$7,'class',16,e,s,gg);
var $8_vc=_v();
_($7,$8_vc);
if(_oz(z,17,e,s,gg)){$8_vc.wxVkey=1
var $8=_n('slot');
_rz(z,$8,'name',18,e,s,gg);
_($8_vc,$8);
}
else if(_oz(z,19,e,s,gg)){$8_vc.wxVkey=2
var $$20=_oz(z,20,e,s,gg);
_($8_vc,$$20);
}
$8_vc.wxXCkey=1;
$8_vc.wxXCkey=1;
_($7_vc,$7);
}
$7_vc.wxXCkey=1;
$4_vc.wxXCkey=1;
$4_vc.wxXCkey=1;
_($0,$3);
var $11=_n('view');
_rz(z,$11,'class',21,e,s,gg);
var $12_vc=_v();
_($11,$12_vc);
if(_oz(z,22,e,s,gg)){$12_vc.wxVkey=1
var $$23=_oz(z,23,e,s,gg);
_($12_vc,$$23);
}
else{$12_vc.wxVkey=2
var $14=_n('slot');
_($12_vc,$14);
}
$12_vc.wxXCkey=1;
$12_vc.wxXCkey=1;
_($0,$11);
var $15_vc=_v();
_($0,$15_vc);
if(_oz(z,24,e,s,gg)){$15_vc.wxVkey=1
var $15=_mz(z,'van-icon',['class',25,'customClass',1,'name',2],[],e,s,gg);
_($15_vc,$15);
}
else{$15_vc.wxVkey=2
var $16=_n('slot');
_rz(z,$16,'name',28,e,s,gg);
_($15_vc,$16);
}
var $17=_n('slot');
_rz(z,$17,'name',29,e,s,gg);
_($0,$17);
$15_vc.wxXCkey=1;
$15_vc.wxXCkey=3;
$1_vc.wxXCkey=1;
$1_vc.wxXCkey=3;
_(r,$0);
return r;
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
function gz$gdm_8(){
if( __WXML_GLOBAL__.ops_cached.$gdm_8)return __WXML_GLOBAL__.ops_cached.$gdm_8
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_8=[
[[7],[3,'border']],
[[7],[3,'center']],
[3,'van-field'],
[[7],[3,'customStyle']],
[[7],[3,'leftIcon']],
[[7],[3,'isLink']],
[[7],[3,'required']],
[[7],[3,'size']],
[[7],[3,'label']],
[[7],[3,'titleWidth']],
[3,'left-icon'],
[3,'icon'],
[3,'label'],
[3,'title'],
[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__body']],[[4],[[5],[[5],[[7],[3,'type']]],[[7],[3,'system']]]]]],
[[2,'==='],[[7],[3,'type']],[1,'textarea']],
[[7],[3,'adjustPosition']],
[[7],[3,'autosize']],
[3,'onBlur'],
[3,'onConfirm'],
[3,'onFocus'],
[3,'onInput'],
[a,[3,'input-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__input']],[[4],[[5],[[5],[[5],[[7],[3,'inputAlign']]],[[7],[3,'type']]],[[9],[[8],'disabled',[[7],[3,'disabled']]],[[8],'error',[[7],[3,'error']]]]]]]]],
[[7],[3,'cursorSpacing']],
[[2,'||'],[[7],[3,'disabled']],[[7],[3,'readonly']]],
[[7],[3,'fixed']],
[[7],[3,'focus']],
[[7],[3,'maxlength']],
[[7],[3,'placeholder']],
[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__placeholder']],[[8],'error',[[7],[3,'error']]]]],
[[7],[3,'placeholderStyle']],
[[7],[3,'selectionEnd']],
[[7],[3,'selectionStart']],
[[7],[3,'showConfirmBar']],
[[7],[3,'value']],
[[7],[3,'adjustPosition']],
[3,'onBlur'],
[3,'onConfirm'],
[3,'onFocus'],
[3,'onInput'],
[a,[3,'input-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__input']],[[4],[[5],[[5],[[7],[3,'inputAlign']]],[[9],[[8],'disabled',[[7],[3,'disabled']]],[[8],'error',[[7],[3,'error']]]]]]]]],
[[7],[3,'confirmHold']],
[[7],[3,'confirmType']],
[[7],[3,'cursorSpacing']],
[[2,'||'],[[7],[3,'disabled']],[[7],[3,'readonly']]],
[[7],[3,'focus']],
[[7],[3,'maxlength']],
[[2,'||'],[[7],[3,'password']],[[2,'==='],[[7],[3,'type']],[1,'password']]],
[[7],[3,'placeholder']],
[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__placeholder']],[[8],'error',[[7],[3,'error']]]]],
[[7],[3,'placeholderStyle']],
[[7],[3,'selectionEnd']],
[[7],[3,'selectionStart']],
[[7],[3,'type']],
[[7],[3,'value']],
[[2,'&&'],[[2,'&&'],[[2,'&&'],[[7],[3,'clearable']],[[7],[3,'focused']]],[[7],[3,'value']]],[[2,'!'],[[7],[3,'readonly']]]],
[3,'onClear'],
[3,'van-field__clear-root van-field__icon-root'],
[3,'clear'],
[3,'16px'],
[3,'onClickIcon'],
[3,'van-field__icon-container'],
[[2,'||'],[[7],[3,'rightIcon']],[[7],[3,'icon']]],
[a,[3,'van-field__icon-root '],[[7],[3,'iconClass']]],
[3,'right-icon-class'],
[[2,'||'],[[7],[3,'rightIcon']],[[7],[3,'icon']]],
[3,'16px'],
[3,'right-icon'],
[3,'icon'],
[3,'van-field__button'],
[3,'button'],
[[7],[3,'errorMessage']],
[a,[3,'van-field__error-message '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__error']],[[4],[[5],[[5],[[7],[3,'errorMessageAlign']]],[[9],[[8],'disabled',[[7],[3,'disabled']]],[[8],'error',[[7],[3,'error']]]]]]]]],
[a,[[7],[3,'errorMessage']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_8}
d_[x[8]]={};
function m8(e,s,r,gg){
var z = gz$gdm_8();
var $0=_mz(z,'van-cell',['border',0,'center',1,'customClass',1,'customStyle',2,'icon',3,'isLink',4,'required',5,'size',6,'title',7,'titleWidth',8],[],e,s,gg);
var $1=_mz(z,'slot',['name',10,'slot',1],[],e,s,gg);
_($0,$1);
var $2=_mz(z,'slot',['name',12,'slot',1],[],e,s,gg);
_($0,$2);
var $3=_n('view');
_rz(z,$3,'class',14,e,s,gg);
var $4_vc=_v();
_($3,$4_vc);
if(_oz(z,15,e,s,gg)){$4_vc.wxVkey=1
var $4=_mz(z,'textarea',['adjustPosition',16,'autoHeight',1,'bind:blur',2,'bind:confirm',3,'bind:focus',4,'bindinput',5,'class',6,'cursorSpacing',7,'disabled',8,'fixed',9,'focus',10,'maxlength',11,'placeholder',12,'placeholderClass',13,'placeholderStyle',14,'selectionEnd',15,'selectionStart',16,'showConfirmBar',17,'value',18],[],e,s,gg);
_($4_vc,$4);
}
else{$4_vc.wxVkey=2
var $5=_mz(z,'input',['adjustPosition',35,'bind:blur',1,'bind:confirm',2,'bind:focus',3,'bindinput',4,'class',5,'confirmHold',6,'confirmType',7,'cursorSpacing',8,'disabled',9,'focus',10,'maxlength',11,'password',12,'placeholder',13,'placeholderClass',14,'placeholderStyle',15,'selectionEnd',16,'selectionStart',17,'type',18,'value',19],[],e,s,gg);
_($4_vc,$5);
}
var $6_vc=_v();
_($3,$6_vc);
if(_oz(z,55,e,s,gg)){$6_vc.wxVkey=1
var $6=_mz(z,'van-icon',['bindtouchstart',56,'class',1,'name',2,'size',3],[],e,s,gg);
_($6_vc,$6);
}
var $7=_mz(z,'view',['bind:tap',60,'class',1],[],e,s,gg);
var $8_vc=_v();
_($7,$8_vc);
if(_oz(z,62,e,s,gg)){$8_vc.wxVkey=1
var $8=_mz(z,'van-icon',['class',63,'customClass',1,'name',2,'size',3],[],e,s,gg);
_($8_vc,$8);
}
var $9=_n('slot');
_rz(z,$9,'name',67,e,s,gg);
_($7,$9);
var $10=_n('slot');
_rz(z,$10,'name',68,e,s,gg);
_($7,$10);
$8_vc.wxXCkey=3;
_($3,$7);
var $11=_n('view');
_rz(z,$11,'class',69,e,s,gg);
var $12=_n('slot');
_rz(z,$12,'name',70,e,s,gg);
_($11,$12);
_($3,$11);
$6_vc.wxXCkey=3;
$4_vc.wxXCkey=1;
$4_vc.wxXCkey=1;
_($0,$3);
var $13_vc=_v();
_($0,$13_vc);
if(_oz(z,71,e,s,gg)){$13_vc.wxVkey=1
var $13=_n('view');
_rz(z,$13,'class',72,e,s,gg);
var $$73=_oz(z,73,e,s,gg);
_($13,$$73);
_($13_vc,$13);
}
$13_vc.wxXCkey=1;
_(r,$0);
return r;
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
function gz$gdm_9(){
if( __WXML_GLOBAL__.ops_cached.$gdm_9)return __WXML_GLOBAL__.ops_cached.$gdm_9
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_9=[
[[7],[3,'inited']],
[3,'onTransitionEnd'],
[a,[3,'van-transition custom-class '],[[7],[3,'classes']]],
[[12],[[6],[[7],[3,'computed']],[3,'rootStyle']],[[5],[[9],[[9],[[8],'currentDuration',[[7],[3,'currentDuration']]],[[8],'display',[[7],[3,'display']]]],[[8],'customStyle',[[7],[3,'customStyle']]]]]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_9}
d_[x[9]]={};
function m9(e,s,r,gg){
var z = gz$gdm_9();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_mz(z,'view',['bind:transitionend',1,'class',1,'style',2],[],e,s,gg);
var $1=_n('slot');
_($0,$1);
_($0_vc,$0);
}
$0_vc.wxXCkey=1;
return r;
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
function gz$gdm_10(){
if( __WXML_GLOBAL__.ops_cached.$gdm_10)return __WXML_GLOBAL__.ops_cached.$gdm_10
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_10=[
[[7],[3,'lockScroll']],
[3,'onClick'],
[3,'noop'],
[3,'van-overlay'],
[a,[3,'z-index: '],[[7],[3,'zIndex']],[3,'; '],[[7],[3,'customStyle']]],
[[7],[3,'duration']],
[[7],[3,'show']],
[3,'onClick'],
[3,'van-overlay'],
[a,[3,'z-index: '],[[7],[3,'zIndex']],[3,'; '],[[7],[3,'customStyle']]],
[[7],[3,'duration']],
[[7],[3,'show']]
];
return __WXML_GLOBAL__.ops_cached.$gdm_10}
d_[x[10]]={};
function m10(e,s,r,gg){
var z = gz$gdm_10();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_mz(z,'van-transition',['bind:tap',1,'catch:touchmove',1,'customClass',2,'customStyle',3,'duration',4,'show',5],[],e,s,gg);
var $1=_n('slot');
_($0,$1);
_($0_vc,$0);
}
else{$0_vc.wxVkey=2
var $2=_mz(z,'van-transition',['bind:tap',7,'customClass',1,'customStyle',2,'duration',3,'show',4],[],e,s,gg);
var $3=_n('slot');
_($2,$3);
_($0_vc,$2);
}
$0_vc.wxXCkey=3;
$0_vc.wxXCkey=3;
return r;
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
function gz$gdm_11(){
if( __WXML_GLOBAL__.ops_cached.$gdm_11)return __WXML_GLOBAL__.ops_cached.$gdm_11
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_11=[
[[2,'&&'],[[2,'==='],[1,'wx'],[1,'wx']],[[7],[3,'show']]],
[3,'onClose'],
[3,'top'],
[[7],[3,'show']],
[3,'popup'],
[3,'noop'],
[3,'phone-input'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyClass']],[[5],[[5],[1,'cell']],[[2,'?:'],[[7],[3,'iptError']],[1,'input-error'],[1,'']]]],
[3,''],
[[7],[3,'_i1']],
[3,''],
[3,'false'],
[3,'inputChange'],
[3,'inputConfirm'],
[3,'cell-ipt'],
[3,''],
[[7],[3,'_i2']],
[3,'digit'],
[[7],[3,'price']],
[3,'clearInput'],
[3,'cell-btn'],
[3,'small'],
[3,'button'],
[3,'primary']
];
return __WXML_GLOBAL__.ops_cached.$gdm_11}
d_[x[11]]={};
function m11(e,s,r,gg){
var z = gz$gdm_11();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_mz(z,'van-overlay',['bind:click',1,'position',1,'show',2],[],e,s,gg);
var $1=_n('view');
_rz(z,$1,'class',4,e,s,gg);
var $2=_mz(z,'view',['catchtap',5,'class',1],[],e,s,gg);
var $3=_mz(z,'van-cell-group',['center',-1,'class',7,'label',1,'title',2,'value',3],[],e,s,gg);
var $4=_mz(z,'van-field',['focus',-1,'required',-1,'useButtonSlot',-1,'adjustPosition',11,'bind:change',1,'bind:confirm',2,'class',3,'label',4,'placeholder',5,'type',6,'value',7],[],e,s,gg);
var $5=_mz(z,'van-button',['bind:click',19,'class',1,'size',2,'slot',3,'type',4],[],e,s,gg);
_($4,$5);
_($3,$4);
_($2,$3);
_($1,$2);
_($0,$1);
_($0_vc,$0);
}
$0_vc.wxXCkey=3;
return r;
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
function gz$gdm_12(){
if( __WXML_GLOBAL__.ops_cached.$gdm_12)return __WXML_GLOBAL__.ops_cached.$gdm_12
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_12=[
[[2,'||'],[[2,'&&'],[[2,'!=='],[[7],[3,'info']],[1,null]],[[2,'!=='],[[7],[3,'info']],[1,'']]],[[7],[3,'dot']]],
[a,[3,'van-info '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'info']],[[8],'dot',[[7],[3,'dot']]]]],[3,' custom-class']],
[[7],[3,'customStyle']],
[a,[[2,'?:'],[[7],[3,'dot']],[1,''],[[7],[3,'info']]]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_12}
d_[x[12]]={};
function m12(e,s,r,gg){
var z = gz$gdm_12();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_mz(z,'view',['class',1,'style',1],[],e,s,gg);
var $$3=_oz(z,3,e,s,gg);
_($0,$$3);
_($0_vc,$0);
}
$0_vc.wxXCkey=1;
return r;
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
function gz$gdm_13(){
if( __WXML_GLOBAL__.ops_cached.$gdm_13)return __WXML_GLOBAL__.ops_cached.$gdm_13
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_13=[
[3,'onClick'],
[[12],[[6],[[7],[3,'computed']],[3,'rootClass']],[[5],[[9],[[8],'classPrefix',[[7],[3,'classPrefix']]],[[8],'name',[[7],[3,'name']]]]]],
[[12],[[6],[[7],[3,'computed']],[3,'rootStyle']],[[5],[[9],[[9],[[8],'customStyle',[[7],[3,'customStyle']]],[[8],'color',[[7],[3,'color']]]],[[8],'size',[[7],[3,'size']]]]]],
[[2,'||'],[[2,'!=='],[[7],[3,'info']],[1,null]],[[7],[3,'dot']]],
[3,'van-icon__info'],
[[7],[3,'dot']],
[[7],[3,'info']],
[[12],[[6],[[7],[3,'computed']],[3,'isImage']],[[5],[[7],[3,'name']]]],
[3,'van-icon__image'],
[3,'aspectFit'],
[[7],[3,'name']]
];
return __WXML_GLOBAL__.ops_cached.$gdm_13}
d_[x[13]]={};
function m13(e,s,r,gg){
var z = gz$gdm_13();
var $0=_mz(z,'view',['bindtap',0,'class',1,'style',1],[],e,s,gg);
var $1_vc=_v();
_($0,$1_vc);
if(_oz(z,3,e,s,gg)){$1_vc.wxVkey=1
var $1=_mz(z,'van-info',['customClass',4,'dot',1,'info',2],[],e,s,gg);
_($1_vc,$1);
}
var $2_vc=_v();
_($0,$2_vc);
if(_oz(z,7,e,s,gg)){$2_vc.wxVkey=1
var $2=_mz(z,'image',['class',8,'mode',1,'src',2],[],e,s,gg);
_($2_vc,$2);
}
$2_vc.wxXCkey=1;
$1_vc.wxXCkey=3;
_(r,$0);
return r;
}
e_[x[13]]={f:m13,j:[],i:[],ti:[],ic:[]}
function gz$gdm_14(){
if( __WXML_GLOBAL__.ops_cached.$gdm_14)return __WXML_GLOBAL__.ops_cached.$gdm_14
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_14=[
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyClass']],[[5],[[5],[1,'package-cell']],[[2,'?:'],[[7],[3,'active']],[1,'package-cellActive'],[1,'']]]],
[[7],[3,'payAssembled']],
[3,'package-cell-monny'],
[a,[[7],[3,'payAssembled']]],
[[7],[3,'merchantDesc']],
[3,'package-cell-desc'],
[a,[[7],[3,'merchantDesc']]],
[[2,'&&'],[[7],[3,'customType']],[[7],[3,'cashbackAssembled']]],
[3,'package-cell-cashbackCustom'],
[a,[[7],[3,'cashbackAssembled']]],
[[7],[3,'cashbackAmountFormattedAssembled']],
[3,'package-cell-cashback mt10'],
[a,[[7],[3,'customTypeCashbackAssembled']]],
[[7],[3,'cashbackAssembled']],
[3,'package-cell-cashback'],
[a,[[7],[3,'cashbackAssembled']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_14}
d_[x[14]]={};
function m14(e,s,r,gg){
var z = gz$gdm_14();
var $0=_n('view');
_rz(z,$0,'class',0,e,s,gg);
var $1=_n('view');
var $2_vc=_v();
_($1,$2_vc);
if(_oz(z,1,e,s,gg)){$2_vc.wxVkey=1
var $2=_n('view');
_rz(z,$2,'class',2,e,s,gg);
var $$3=_oz(z,3,e,s,gg);
_($2,$$3);
_($2_vc,$2);
}
var $4_vc=_v();
_($1,$4_vc);
if(_oz(z,4,e,s,gg)){$4_vc.wxVkey=1
var $4=_n('view');
_rz(z,$4,'class',5,e,s,gg);
var $$6=_oz(z,6,e,s,gg);
_($4,$$6);
_($4_vc,$4);
}
$4_vc.wxXCkey=1;
$2_vc.wxXCkey=1;
_($0,$1);
var $6=_n('view');
var $7_vc=_v();
_($6,$7_vc);
if(_oz(z,7,e,s,gg)){$7_vc.wxVkey=1
var $7=_n('view');
_rz(z,$7,'class',8,e,s,gg);
var $8=_n('view');
var $$9=_oz(z,9,e,s,gg);
_($8,$$9);
_($7,$8);
var $10_vc=_v();
_($7,$10_vc);
if(_oz(z,10,e,s,gg)){$10_vc.wxVkey=1
var $10=_n('view');
_rz(z,$10,'class',11,e,s,gg);
var $$12=_oz(z,12,e,s,gg);
_($10,$$12);
_($10_vc,$10);
}
$10_vc.wxXCkey=1;
_($7_vc,$7);
}
else if(_oz(z,13,e,s,gg)){$7_vc.wxVkey=2
var $12=_n('view');
_rz(z,$12,'class',14,e,s,gg);
var $$15=_oz(z,15,e,s,gg);
_($12,$$15);
_($7_vc,$12);
}
$7_vc.wxXCkey=1;
$7_vc.wxXCkey=1;
_($0,$6);
_(r,$0);
return r;
}
e_[x[14]]={f:m14,j:[],i:[],ti:[],ic:[]}
function gz$gdm_15(){
if( __WXML_GLOBAL__.ops_cached.$gdm_15)return __WXML_GLOBAL__.ops_cached.$gdm_15
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_15=[
[3,'custom-class van-sticky'],
[[12],[[6],[[7],[3,'computed']],[3,'containerStyle']],[[5],[[9],[[9],[[8],'fixed',[[7],[3,'fixed']]],[[8],'height',[[7],[3,'height']]]],[[8],'zIndex',[[7],[3,'zIndex']]]]]],
[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'sticky-wrap']],[[8],'fixed',[[7],[3,'fixed']]]]],
[[12],[[6],[[7],[3,'computed']],[3,'wrapStyle']],[[5],[[9],[[9],[[9],[[8],'fixed',[[7],[3,'fixed']]],[[8],'offsetTop',[[7],[3,'offsetTop']]]],[[8],'transform',[[7],[3,'transform']]]],[[8],'zIndex',[[7],[3,'zIndex']]]]]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_15}
d_[x[15]]={};
function m15(e,s,r,gg){
var z = gz$gdm_15();
var $0=_mz(z,'view',['class',0,'style',1],[],e,s,gg);
var $1=_mz(z,'view',['class',2,'style',1],[],e,s,gg);
var $2=_n('slot');
_($1,$2);
_($0,$1);
_(r,$0);
return r;
}
e_[x[15]]={f:m15,j:[],i:[],ti:[],ic:[]}
function gz$gdm_16(){
if( __WXML_GLOBAL__.ops_cached.$gdm_16)return __WXML_GLOBAL__.ops_cached.$gdm_16
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_16=[
[[2,'&&'],[[2,'!=='],[[7],[3,'info']],[1,null]],[[2,'!=='],[[7],[3,'info']],[1,'']]],
[3,'custom-class van-info'],
[[7],[3,'customStyle']],
[a,[[7],[3,'info']]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_16}
d_[x[16]]={};
function m16(e,s,r,gg){
var z = gz$gdm_16();
var $0_vc=_v();
_(r,$0_vc);
if(_oz(z,0,e,s,gg)){$0_vc.wxVkey=1
var $0=_mz(z,'view',['class',1,'style',1],[],e,s,gg);
var $$3=_oz(z,3,e,s,gg);
_($0,$$3);
_($0_vc,$0);
}
$0_vc.wxXCkey=1;
return r;
}
e_[x[16]]={f:m16,j:[],i:[],ti:[],ic:[]}
function gz$gdm_17(){
if( __WXML_GLOBAL__.ops_cached.$gdm_17)return __WXML_GLOBAL__.ops_cached.$gdm_17
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_17=[
[3,'onClick'],
[a,[3,'custom-class '],[[7],[3,'classPrefix']],[3,' '],[[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isSrc']],[[5],[[7],[3,'name']]]],[1,'van-icon--image'],[[2,'+'],[[2,'+'],[[7],[3,'classPrefix']],[1,'-']],[[7],[3,'name']]]]],
[a,[[2,'?:'],[[7],[3,'color']],[[2,'+'],[[2,'+'],[1,'color: '],[[7],[3,'color']]],[1,';']],[1,'']],[[2,'?:'],[[7],[3,'size']],[[2,'+'],[[2,'+'],[1,'font-size: '],[[7],[3,'size']]],[1,';']],[1,'']],[[7],[3,'customStyle']]],
[[2,'!=='],[[7],[3,'info']],[1,null]],
[3,'van-icon__info'],
[[7],[3,'info']],
[[12],[[6],[[7],[3,'utils']],[3,'isSrc']],[[5],[[7],[3,'name']]]],
[3,'van-icon__image'],
[3,'aspectFit'],
[[7],[3,'name']]
];
return __WXML_GLOBAL__.ops_cached.$gdm_17}
d_[x[17]]={};
function m17(e,s,r,gg){
var z = gz$gdm_17();
var $0=_mz(z,'view',['bind:tap',0,'class',1,'style',1],[],e,s,gg);
var $1_vc=_v();
_($0,$1_vc);
if(_oz(z,3,e,s,gg)){$1_vc.wxVkey=1
var $1=_mz(z,'van-info',['customClass',4,'info',1],[],e,s,gg);
_($1_vc,$1);
}
var $2_vc=_v();
_($0,$2_vc);
if(_oz(z,6,e,s,gg)){$2_vc.wxVkey=1
var $2=_mz(z,'image',['class',7,'mode',1,'src',2],[],e,s,gg);
_($2_vc,$2);
}
$2_vc.wxXCkey=1;
$1_vc.wxXCkey=3;
_(r,$0);
return r;
}
e_[x[17]]={f:m17,j:[],i:[],ti:[],ic:[]}
function gz$gdm_18(){
if( __WXML_GLOBAL__.ops_cached.$gdm_18)return __WXML_GLOBAL__.ops_cached.$gdm_18
var a=11;
__WXML_GLOBAL__.ops_cached.$gdm_18=[
[3,'scrollTap'],
[3,'navbar'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyStyle']],[[5],[[5],[1,'']],[[9],[[9],[[8],'paddingTop',[[2,'+'],[[7],[3,'statusBarHeight']],[1,'px']]],[[8],'backgroundColor',[[7],[3,'$navBgc']]]],[[8],'height',[[2,'+'],[[7],[3,'navContentHeight']],[1,'px']]]]]],
[[7],[3,'isShowBack']],
[3,'backBtn'],
[3,'navbar-back'],
[[2,'!'],[[7],[3,'circleBackBtn']]],
[3,'navbar-back-noCircle'],
[3,'navbar-back-noCircle-icon'],
[3,'https://img0.didiglobal.com/static/gstar/img/py3KOCcsq31656658562858.png'],
[3,'20px'],
[3,'navbar-back-circle'],
[3,'navbar-back-circle-icon'],
[3,'https://img0.didiglobal.com/static/gstar/img/SCL4fLYIZ81656658612558.png'],
[3,'20px'],
[3,'navbar-left'],
[3,'left'],
[[7],[3,'navTitle']],
[3,'navbar-title'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyStyle']],[[5],[[5],[1,'']],[[8],'color',[[7],[3,'navTitleColor']]]]],
[a,[[7],[3,'navTitle']]],
[3,'navbar-solt'],
[[12],[[6],[[7],[3,'__stringify__']],[3,'stringifyStyle']],[[5],[[5],[1,'']],[[8],'height',[[2,'+'],[[7],[3,'navHeight']],[1,'px']]]]]
];
return __WXML_GLOBAL__.ops_cached.$gdm_18}
d_[x[18]]={};
function m18(e,s,r,gg){
var z = gz$gdm_18();
var $0=_n('view');
var $1=_n('van-sticky');
_rz(z,$1,'bind:scroll',0,e,s,gg);
_($0,$1);
var $2=_mz(z,'view',['class',1,'style',1],[],e,s,gg);
var $3_vc=_v();
_($2,$3_vc);
if(_oz(z,3,e,s,gg)){$3_vc.wxVkey=1
var $3=_mz(z,'view',['bindtap',4,'class',1],[],e,s,gg);
var $4_vc=_v();
_($3,$4_vc);
if(_oz(z,6,e,s,gg)){$4_vc.wxVkey=1
var $4=_n('view');
_rz(z,$4,'class',7,e,s,gg);
var $5=_mz(z,'van-icon',['class',8,'name',1,'size',2],[],e,s,gg);
_($4,$5);
_($4_vc,$4);
}
else{$4_vc.wxVkey=2
var $6=_n('view');
_rz(z,$6,'class',11,e,s,gg);
var $7=_mz(z,'van-icon',['class',12,'name',1,'size',2],[],e,s,gg);
_($6,$7);
_($4_vc,$6);
}
$4_vc.wxXCkey=3;
$4_vc.wxXCkey=3;
_($3_vc,$3);
}
var $8=_n('view');
_rz(z,$8,'class',15,e,s,gg);
var $9=_n('slot');
_rz(z,$9,'name',16,e,s,gg);
_($8,$9);
_($2,$8);
var $10_vc=_v();
_($2,$10_vc);
if(_oz(z,17,e,s,gg)){$10_vc.wxVkey=1
var $10=_mz(z,'view',['class',18,'style',1],[],e,s,gg);
var $$20=_oz(z,20,e,s,gg);
_($10,$$20);
_($10_vc,$10);
}
var $12=_n('view');
_rz(z,$12,'class',21,e,s,gg);
var $13=_n('slot');
_($12,$13);
_($2,$12);
$10_vc.wxXCkey=1;
$3_vc.wxXCkey=3;
_($0,$2);
var $14=_n('view');
_rz(z,$14,'style',22,e,s,gg);
_($0,$14);
_(r,$0);
return r;
}
e_[x[18]]={f:m18,j:[],i:[],ti:[],ic:[]}
var nv_require = function() {
    var nnm = {"p_wxs/wxs/index0e4655eb.wxs":np_7,"p_wxs/wxs/index1d6fc162.wxs":np_12,"p_wxs/wxs/index42057314.wxs":np_15,"p_wxs/wxs/stringify7e486c90.wxs":np_0,"p_wxs/wxs/utils0d11dbae.wxs":np_10,"p_wxs/wxs/utils19e67034.wxs":np_17,"p_wxs/wxs/utils2ee283bc.wxs":np_3}
;
    var nom = {};
    return function(n) {
        return function() {
            if (!nnm[n]) return undefined;
            try {
                if (!nom[n]) nom[n] = nnm[n]();
                return nom[n];
            } catch (e) {
                e.message = e.message.replace(/nv_/g, '');
                var tmp = e.stack.substring(0, e.stack.lastIndexOf(n));
                e.stack = tmp.substring(0, tmp.lastIndexOf('\n'));
                e.stack = e.stack.replace(/\snv_/g, ' ');
                e.stack = $gstack(e.stack);
                e.stack += '\n    at ' + n.substring(2);
                console.error(e);
            }
        }
    }
}();
if(!f_['pages/giftcard/package-list.wxml']) {
   f_['pages/giftcard/package-list.wxml'] = {};
}
f_['pages/giftcard/package-list.wxml']['__stringify__'] = f_['wxs/wxs/stringify7e486c90.wxs'] || nv_require("p_wxs/wxs/stringify7e486c90.wxs");
f_['pages/giftcard/package-list.wxml']['__stringify__']();
f_['wxs/wxs/stringify7e486c90.wxs'] = nv_require("p_wxs/wxs/stringify7e486c90.wxs");
function np_0() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module) {

function objectKeys (obj) {
  if (false) {} else {
    var keys = []
    var stackMap = {
      '{': '}',
      '[': ']',
      '(': ')'
    }
    var shiftMap = {
      'n': '\n',
      'b': '\b',
      'f': '\f',
      'r': '\r',
      't': '\t'
    }
    if (typeof obj === 'object') {
      var objStr = JSON.stringify(obj)
      if (objStr[0] === '{' && objStr[objStr.length - 1] === '}') {
        var key = ''
        var inKey = true
        var stack = []
        var shift = false
        for (var i = 1; i < objStr.length - 1; i++) {
          var item = objStr[i]
          if (inKey) {
            if (item === ':') {
              keys.push(key.slice(1, -1))
              key = ''
              inKey = false
            } else {
              if (shift === false && item === '\\') {
                shift = true
                continue
              }
              if (shift) {
                item = shiftMap[item] || item
                shift = false
              }
              key += item
            }
          } else {
            if (stackMap[item]) {
              stack.push(item)
            } else if (stackMap[stack[stack.length - 1]] === item) {
              stack.pop()
            } else if (stack.length === 0 && item === ',') {
              inKey = true
            }
          }
        }
      }
    }
    return keys
  }
}

function genRegExp (str, flags) {
  if (false) {} else {
    return getRegExp(str, flags)
  }
}

function extend (target, from) {
  var fromKeys = objectKeys(from)
  for (var i = 0; i < fromKeys.length; i++) {
    var key = fromKeys[i]
    target[key] = from[key]
  }
  return target
}

function concat (a, b) {
  return a ? b ? (a + ' ' + b) : a : (b || '')
}

function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

function likeArray (arr) {
  if (false) {} else {
    return arr && arr.constructor === 'Array'
  }
}

function isDef (v) {
  return v !== undefined && v !== null
}

function stringifyDynamicClass (value) {
  if (!value) return ''
  if (likeArray(value)) {
    return stringifyArray(value)
  }
  if (isObject(value)) {
    return stringifyObject(value)
  }
  if (typeof value === 'string') {
    return value
  }
  return ''
}

function stringifyArray (value) {
  var res = ''
  var stringified
  for (var i = 0; i < value.length; i++) {
    if (isDef(stringified = stringifyDynamicClass(value[i])) && stringified !== '') {
      if (res) res += ' '
      res += stringified
    }
  }
  return res
}

var mpxDashReg = genRegExp('(.+)MpxDash$')
// 转义字符在wxs正则中存在平台兼容性问题，用[$]规避使用转义字符
var mpxDashReplaceReg = genRegExp('[$]', 'g')

function stringifyObject (value) {
  var res = ''
  var objKeys = objectKeys(value)
  for (var i = 0; i < objKeys.length; i++) {
    var key = objKeys[i]
    if (value[key]) {
      if (res) res += ' '
      if (mpxDashReg.test(key)) {
        key = mpxDashReg.exec(key)[1].replace(mpxDashReplaceReg, '-')
      }
      res += key
    }
  }
  return res
}

function hump2dash (value) {
  var reg = genRegExp('[A-Z]', 'g')
  return value.replace(reg, function (match) {
    return '-' + match.toLowerCase()
  })
}

function dash2hump (value) {
  var reg = genRegExp('-([a-z])', 'g')
  return value.replace(reg, function (match, p1) {
    return p1.toUpperCase()
  })
}

function parseStyleText (cssText) {
  var res = {}
  var listDelimiter = genRegExp(';(?![^(]*[)])', 'g')
  var propertyDelimiter = genRegExp(':(.+)')
  var arr = cssText.split(listDelimiter)
  for (var i = 0; i < arr.length; i++) {
    var item = arr[i]
    if (item) {
      var tmp = item.split(propertyDelimiter)
      if (tmp.length > 1) {
        var k = dash2hump(tmp[0].trim())
        res[k] = tmp[1].trim()
      }
    }
  }
  return res
}

function genStyleText (styleObj) {
  var res = ''
  var objKeys = objectKeys(styleObj)

  for (var i = 0; i < objKeys.length; i++) {
    var key = objKeys[i]
    var item = styleObj[key]
    res += hump2dash(key) + ':' + item + ';'
  }
  return res
}

function mergeObjectArray (arr) {
  var res = {}
  for (var i = 0; i < arr.length; i++) {
    if (arr[i]) {
      extend(res, arr[i])
    }
  }
  return res
}

function normalizeDynamicStyle (value) {
  if (!value) return {}
  if (likeArray(value)) {
    return mergeObjectArray(value)
  }
  if (typeof value === 'string') {
    return parseStyleText(value)
  }
  return value
}

module.exports = {
  stringifyClass: function (staticClass, dynamicClass) {
    if (typeof staticClass !== 'string') {
      return console.log('Template attr class must be a string!')
    }
    return concat(staticClass, stringifyDynamicClass(dynamicClass))
  },
  stringifyStyle: function (staticStyle, dynamicStyle) {
    var normalizedDynamicStyle = normalizeDynamicStyle(dynamicStyle)
    var parsedStaticStyle = typeof staticStyle === 'string' ? parseStyleText(staticStyle) : {}
    return genStyleText(extend(parsedStaticStyle, normalizedDynamicStyle))
  }
}


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/package-questions936d56f6/index.wxml']) {
   f_['components/package-questions936d56f6/index.wxml'] = {};
}
f_['components/package-questions936d56f6/index.wxml']['__stringify__'] = f_['wxs/wxs/stringify7e486c90.wxs'] || nv_require("p_wxs/wxs/stringify7e486c90.wxs");
f_['components/package-questions936d56f6/index.wxml']['__stringify__']();
f_['wxs/wxs/stringify7e486c90.wxs'] = nv_require("p_wxs/wxs/stringify7e486c90.wxs");
if(!f_['components/vant-weapp27f0c1f3/button/index.wxml']) {
   f_['components/vant-weapp27f0c1f3/button/index.wxml'] = {};
}
f_['components/vant-weapp27f0c1f3/button/index.wxml']['utils'] = f_['wxs/wxs/utils2ee283bc.wxs'] || nv_require("p_wxs/wxs/utils2ee283bc.wxs");
f_['components/vant-weapp27f0c1f3/button/index.wxml']['utils']();
f_['wxs/wxs/utils2ee283bc.wxs'] = nv_require("p_wxs/wxs/utils2ee283bc.wxs");
function np_3() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var bem = (__webpack_require__(1)/* .bem */ .P);
var memoize = (__webpack_require__(4)/* .memoize */ .H);

function isSrc(url) {
  return url.indexOf('http') === 0 || url.indexOf('data:image') === 0 || url.indexOf('//') === 0;
}

module.exports = {
  bem: memoize(bem),
  isSrc: isSrc,
  memoize: memoize
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var array = __webpack_require__(2);
var object = __webpack_require__(3);
var PREFIX = 'van-';

function join(name, mods) {
  name = PREFIX + name;
  mods = mods.map(function(mod) {
    return name + '--' + mod;
  });
  mods.unshift(name);
  return mods.join(' ');
}

function traversing(mods, conf) {
  if (!conf) {
    return;
  }

  if (typeof conf === 'string' || typeof conf === 'number') {
    mods.push(conf);
  } else if (array.isArray(conf)) {
    conf.forEach(function(item) {
      traversing(mods, item);
    });
  } else if (typeof conf === 'object') {
    object.keys(conf).forEach(function(key) {
      conf[key] && mods.push(key);
    });
  }
}

function bem(name, conf) {
  var mods = [];
  traversing(mods, conf);
  return join(name, mods);
}

module.exports.P = bem;


/***/ }),
/* 2 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ }),
/* 3 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 4 */
/***/ (function(module) {

/**
 * Simple memoize
 * wxs doesn't support fn.apply, so this memoize only support up to 2 args
 */

function isPrimitive(value) {
  var type = typeof value;
  return (
    type === 'boolean' ||
    type === 'number' ||
    type === 'string' ||
    type === 'undefined' ||
    value === null
  );
}

// mock simple fn.call in wxs
function call(fn, args) {
  if (args.length === 2) {
    return fn(args[0], args[1]);
  }

  if (args.length === 1) {
    return fn(args[0]);
  }

  return fn();
}

function serializer(args) {
  if (args.length === 1 && isPrimitive(args[0])) {
    return args[0];
  }
  var obj = {};
  for (var i = 0; i < args.length; i++) {
    obj['key' + i] = args[i];
  }
  return JSON.stringify(obj);
}

function memoize(fn) {
  var cache = {};

  return function() {
    var key = serializer(arguments);
    if (cache[key] === undefined) {
      cache[key] = call(fn, arguments);
    }

    return cache[key];
  };
}

module.exports.H = memoize;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/vant-weapp27f0c1f3/cell/index.wxml']) {
   f_['components/vant-weapp27f0c1f3/cell/index.wxml'] = {};
}
f_['components/vant-weapp27f0c1f3/cell/index.wxml']['utils'] = f_['wxs/wxs/utils2ee283bc.wxs'] || nv_require("p_wxs/wxs/utils2ee283bc.wxs");
f_['components/vant-weapp27f0c1f3/cell/index.wxml']['utils']();
f_['wxs/wxs/utils2ee283bc.wxs'] = nv_require("p_wxs/wxs/utils2ee283bc.wxs");
if(!f_['components/vant-weapp27f0c1f3/field/index.wxml']) {
   f_['components/vant-weapp27f0c1f3/field/index.wxml'] = {};
}
f_['components/vant-weapp27f0c1f3/field/index.wxml']['utils'] = f_['wxs/wxs/utils2ee283bc.wxs'] || nv_require("p_wxs/wxs/utils2ee283bc.wxs");
f_['components/vant-weapp27f0c1f3/field/index.wxml']['utils']();
f_['wxs/wxs/utils2ee283bc.wxs'] = nv_require("p_wxs/wxs/utils2ee283bc.wxs");
if(!f_['components/vant/weapp05bd39c0/transition/index.wxml']) {
   f_['components/vant/weapp05bd39c0/transition/index.wxml'] = {};
}
f_['components/vant/weapp05bd39c0/transition/index.wxml']['computed'] = f_['wxs/wxs/index0e4655eb.wxs'] || nv_require("p_wxs/wxs/index0e4655eb.wxs");
f_['components/vant/weapp05bd39c0/transition/index.wxml']['computed']();
f_['wxs/wxs/index0e4655eb.wxs'] = nv_require("p_wxs/wxs/index0e4655eb.wxs");
function np_7() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var style = __webpack_require__(1);

function rootStyle(data) {
  return style([
    {
      '-webkit-transition-duration': data.currentDuration + 'ms',
      'transition-duration': data.currentDuration + 'ms',
    },
    data.display ? null : 'display: none',
    data.customStyle,
  ]);
}

module.exports = {
  rootStyle: rootStyle,
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var object = __webpack_require__(2);
var array = __webpack_require__(3);

function kebabCase(word) {
  var newWord = word
    .replace(getRegExp("[A-Z]", 'g'), function (i) {
      return '-' + i;
    })
    .toLowerCase()

  return newWord;
}

function style(styles) {
  if (array.isArray(styles)) {
    return styles
      .filter(function (item) {
        return item != null && item !== '';
      })
      .map(function (item) {
        return style(item);
      })
      .join(';');
  }

  if ('Object' === styles.constructor) {
    return object
      .keys(styles)
      .filter(function (key) {
        return styles[key] != null && styles[key] !== '';
      })
      .map(function (key) {
        return [kebabCase(key), [styles[key]]].join(':');
      })
      .join(';');
  }

  return styles;
}

module.exports = style;


/***/ }),
/* 2 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 3 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/price-popup1388dd35/index.wxml']) {
   f_['components/price-popup1388dd35/index.wxml'] = {};
}
f_['components/price-popup1388dd35/index.wxml']['__stringify__'] = f_['wxs/wxs/stringify7e486c90.wxs'] || nv_require("p_wxs/wxs/stringify7e486c90.wxs");
f_['components/price-popup1388dd35/index.wxml']['__stringify__']();
f_['wxs/wxs/stringify7e486c90.wxs'] = nv_require("p_wxs/wxs/stringify7e486c90.wxs");
if(!f_['components/vant/weapp05bd39c0/info/index.wxml']) {
   f_['components/vant/weapp05bd39c0/info/index.wxml'] = {};
}
f_['components/vant/weapp05bd39c0/info/index.wxml']['utils'] = f_['wxs/wxs/utils0d11dbae.wxs'] || nv_require("p_wxs/wxs/utils0d11dbae.wxs");
f_['components/vant/weapp05bd39c0/info/index.wxml']['utils']();
f_['wxs/wxs/utils0d11dbae.wxs'] = nv_require("p_wxs/wxs/utils0d11dbae.wxs");
function np_10() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var bem = __webpack_require__(1);
var memoize = __webpack_require__(4);
var addUnit = __webpack_require__(5);

module.exports = {
  bem: memoize(bem),
  memoize: memoize,
  addUnit: addUnit
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var array = __webpack_require__(2);
var object = __webpack_require__(3);
var PREFIX = 'van-';

function join(name, mods) {
  name = PREFIX + name;
  mods = mods.map(function(mod) {
    return name + '--' + mod;
  });
  mods.unshift(name);
  return mods.join(' ');
}

function traversing(mods, conf) {
  if (!conf) {
    return;
  }

  if (typeof conf === 'string' || typeof conf === 'number') {
    mods.push(conf);
  } else if (array.isArray(conf)) {
    conf.forEach(function(item) {
      traversing(mods, item);
    });
  } else if (typeof conf === 'object') {
    object.keys(conf).forEach(function(key) {
      conf[key] && mods.push(key);
    });
  }
}

function bem(name, conf) {
  var mods = [];
  traversing(mods, conf);
  return join(name, mods);
}

module.exports = bem;


/***/ }),
/* 2 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ }),
/* 3 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 4 */
/***/ (function(module) {

/**
 * Simple memoize
 * wxs doesn't support fn.apply, so this memoize only support up to 2 args
 */
/* eslint-disable */

function isPrimitive(value) {
  var type = typeof value;
  return (
    type === 'boolean' ||
    type === 'number' ||
    type === 'string' ||
    type === 'undefined' ||
    value === null
  );
}

// mock simple fn.call in wxs
function call(fn, args) {
  if (args.length === 2) {
    return fn(args[0], args[1]);
  }

  if (args.length === 1) {
    return fn(args[0]);
  }

  return fn();
}

function serializer(args) {
  if (args.length === 1 && isPrimitive(args[0])) {
    return args[0];
  }
  var obj = {};
  for (var i = 0; i < args.length; i++) {
    obj['key' + i] = args[i];
  }
  return JSON.stringify(obj);
}

function memoize(fn) {
  var cache = {};

  return function() {
    var key = serializer(arguments);
    if (cache[key] === undefined) {
      cache[key] = call(fn, arguments);
    }

    return cache[key];
  };
}

module.exports = memoize;


/***/ }),
/* 5 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('^-?\d+(\.\d+)?$');

function addUnit(value) {
  if (value == null) {
    return undefined;
  }

  return REGEXP.test('' + value) ? value + 'px' : value;
}

module.exports = addUnit;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/vant/weapp05bd39c0/icon/index.wxml']) {
   f_['components/vant/weapp05bd39c0/icon/index.wxml'] = {};
}
f_['components/vant/weapp05bd39c0/icon/index.wxml']['computed'] = f_['wxs/wxs/index1d6fc162.wxs'] || nv_require("p_wxs/wxs/index1d6fc162.wxs");
f_['components/vant/weapp05bd39c0/icon/index.wxml']['computed']();
f_['wxs/wxs/index1d6fc162.wxs'] = nv_require("p_wxs/wxs/index1d6fc162.wxs");
function np_12() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var style = __webpack_require__(1);
var addUnit = __webpack_require__(4);

function isImage(name) {
  return name.indexOf('/') !== -1;
}

function rootClass(data) {
  var classes = ['custom-class'];

  if (data.classPrefix != null) {
    classes.push(data.classPrefix);
  }

  if (isImage(data.name)) {
    classes.push('van-icon--image');
  } else if (data.classPrefix != null) {
    classes.push(data.classPrefix + '-' + data.name);
  }

  return classes.join(' ');
}

function rootStyle(data) {
  return style([
    {
      color: data.color,
      'font-size': addUnit(data.size),
    },
    data.customStyle,
  ]);
}

module.exports = {
  isImage: isImage,
  rootClass: rootClass,
  rootStyle: rootStyle,
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var object = __webpack_require__(2);
var array = __webpack_require__(3);

function kebabCase(word) {
  var newWord = word
    .replace(getRegExp("[A-Z]", 'g'), function (i) {
      return '-' + i;
    })
    .toLowerCase()

  return newWord;
}

function style(styles) {
  if (array.isArray(styles)) {
    return styles
      .filter(function (item) {
        return item != null && item !== '';
      })
      .map(function (item) {
        return style(item);
      })
      .join(';');
  }

  if ('Object' === styles.constructor) {
    return object
      .keys(styles)
      .filter(function (key) {
        return styles[key] != null && styles[key] !== '';
      })
      .map(function (key) {
        return [kebabCase(key), [styles[key]]].join(':');
      })
      .join(';');
  }

  return styles;
}

module.exports = style;


/***/ }),
/* 2 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 3 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ }),
/* 4 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('^-?\d+(\.\d+)?$');

function addUnit(value) {
  if (value == null) {
    return undefined;
  }

  return REGEXP.test('' + value) ? value + 'px' : value;
}

module.exports = addUnit;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/package-cell4a6b6d6c/index.wxml']) {
   f_['components/package-cell4a6b6d6c/index.wxml'] = {};
}
f_['components/package-cell4a6b6d6c/index.wxml']['__stringify__'] = f_['wxs/wxs/stringify7e486c90.wxs'] || nv_require("p_wxs/wxs/stringify7e486c90.wxs");
f_['components/package-cell4a6b6d6c/index.wxml']['__stringify__']();
f_['wxs/wxs/stringify7e486c90.wxs'] = nv_require("p_wxs/wxs/stringify7e486c90.wxs");
if(!f_['components/vant/dist/sticky/index.wxml']) {
   f_['components/vant/dist/sticky/index.wxml'] = {};
}
f_['components/vant/dist/sticky/index.wxml']['computed'] = f_['wxs/wxs/index42057314.wxs'] || nv_require("p_wxs/wxs/index42057314.wxs");
f_['components/vant/dist/sticky/index.wxml']['computed']();
f_['wxs/wxs/index42057314.wxs'] = nv_require("p_wxs/wxs/index42057314.wxs");
function np_15() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var style = __webpack_require__(1);
var addUnit = __webpack_require__(4);

function wrapStyle(data) {
  return style({
    transform: data.transform
      ? 'translate3d(0, ' + data.transform + 'px, 0)'
      : '',
    top: data.fixed ? addUnit(data.offsetTop) : '',
    'z-index': data.zIndex,
  });
}

function containerStyle(data) {
  return style({
    height: data.fixed ? addUnit(data.height) : '',
    'z-index': data.zIndex,
  });
}

module.exports = {
  wrapStyle: wrapStyle,
  containerStyle: containerStyle,
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var object = __webpack_require__(2);
var array = __webpack_require__(3);

function kebabCase(word) {
  var newWord = word
    .replace(getRegExp("[A-Z]", 'g'), function (i) {
      return '-' + i;
    })
    .toLowerCase()

  return newWord;
}

function style(styles) {
  if (array.isArray(styles)) {
    return styles
      .filter(function (item) {
        return item != null && item !== '';
      })
      .map(function (item) {
        return style(item);
      })
      .join(';');
  }

  if ('Object' === styles.constructor) {
    return object
      .keys(styles)
      .filter(function (key) {
        return styles[key] != null && styles[key] !== '';
      })
      .map(function (key) {
        return [kebabCase(key), [styles[key]]].join(':');
      })
      .join(';');
  }

  return styles;
}

module.exports = style;


/***/ }),
/* 2 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 3 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ }),
/* 4 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('^-?\d+(\.\d+)?$');

function addUnit(value) {
  if (value == null) {
    return undefined;
  }

  return REGEXP.test('' + value) ? value + 'px' : value;
}

module.exports = addUnit;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/vant/dist/sticky/index.wxml']) {
   f_['components/vant/dist/sticky/index.wxml'] = {};
}
f_['components/vant/dist/sticky/index.wxml']['utils'] = f_['wxs/wxs/utils19e67034.wxs'] || nv_require("p_wxs/wxs/utils19e67034.wxs");
f_['components/vant/dist/sticky/index.wxml']['utils']();
f_['wxs/wxs/utils19e67034.wxs'] = nv_require("p_wxs/wxs/utils19e67034.wxs");
function np_17() {
var module = { exports: {} };
module.exports = 
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var bem = __webpack_require__(1);
var memoize = __webpack_require__(4);
var addUnit = __webpack_require__(5);

module.exports = {
  bem: memoize(bem),
  memoize: memoize,
  addUnit: addUnit
};


/***/ }),
/* 1 */
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable */
var array = __webpack_require__(2);
var object = __webpack_require__(3);
var PREFIX = 'van-';

function join(name, mods) {
  name = PREFIX + name;
  mods = mods.map(function(mod) {
    return name + '--' + mod;
  });
  mods.unshift(name);
  return mods.join(' ');
}

function traversing(mods, conf) {
  if (!conf) {
    return;
  }

  if (typeof conf === 'string' || typeof conf === 'number') {
    mods.push(conf);
  } else if (array.isArray(conf)) {
    conf.forEach(function(item) {
      traversing(mods, item);
    });
  } else if (typeof conf === 'object') {
    object.keys(conf).forEach(function(key) {
      conf[key] && mods.push(key);
    });
  }
}

function bem(name, conf) {
  var mods = [];
  traversing(mods, conf);
  return join(name, mods);
}

module.exports = bem;


/***/ }),
/* 2 */
/***/ (function(module) {

function isArray(array) {
  return array && array.constructor === 'Array';
}

module.exports.isArray = isArray;


/***/ }),
/* 3 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('{|}|"', 'g');

function keys(obj) {
  return JSON.stringify(obj)
    .replace(REGEXP, '')
    .split(',')
    .map(function(item) {
      return item.split(':')[0];
    });
}

module.exports.keys = keys;


/***/ }),
/* 4 */
/***/ (function(module) {

/**
 * Simple memoize
 * wxs doesn't support fn.apply, so this memoize only support up to 2 args
 */
/* eslint-disable */

function isPrimitive(value) {
  var type = typeof value;
  return (
    type === 'boolean' ||
    type === 'number' ||
    type === 'string' ||
    type === 'undefined' ||
    value === null
  );
}

// mock simple fn.call in wxs
function call(fn, args) {
  if (args.length === 2) {
    return fn(args[0], args[1]);
  }

  if (args.length === 1) {
    return fn(args[0]);
  }

  return fn();
}

function serializer(args) {
  if (args.length === 1 && isPrimitive(args[0])) {
    return args[0];
  }
  var obj = {};
  for (var i = 0; i < args.length; i++) {
    obj['key' + i] = args[i];
  }
  return JSON.stringify(obj);
}

function memoize(fn) {
  var cache = {};

  return function() {
    var key = serializer(arguments);
    if (cache[key] === undefined) {
      cache[key] = call(fn, arguments);
    }

    return cache[key];
  };
}

module.exports = memoize;


/***/ }),
/* 5 */
/***/ (function(module) {

/* eslint-disable */
var REGEXP = getRegExp('^-?\d+(\.\d+)?$');

function addUnit(value) {
  if (value == null) {
    return undefined;
  }

  return REGEXP.test('' + value) ? value + 'px' : value;
}

module.exports = addUnit;


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	return __webpack_exports__ && __webpack_exports__.__esModule? __webpack_exports__["default"] : __webpack_exports__;
/******/ 	
/******/ })()
;
return module.exports;
}
if(!f_['components/vant-weapp27f0c1f3/icon/index.wxml']) {
   f_['components/vant-weapp27f0c1f3/icon/index.wxml'] = {};
}
f_['components/vant-weapp27f0c1f3/icon/index.wxml']['utils'] = f_['wxs/wxs/utils2ee283bc.wxs'] || nv_require("p_wxs/wxs/utils2ee283bc.wxs");
f_['components/vant-weapp27f0c1f3/icon/index.wxml']['utils']();
f_['wxs/wxs/utils2ee283bc.wxs'] = nv_require("p_wxs/wxs/utils2ee283bc.wxs");
if(!f_['components/indexc0adbb64/index.wxml']) {
   f_['components/indexc0adbb64/index.wxml'] = {};
}
f_['components/indexc0adbb64/index.wxml']['__stringify__'] = f_['wxs/wxs/stringify7e486c90.wxs'] || nv_require("p_wxs/wxs/stringify7e486c90.wxs");
f_['components/indexc0adbb64/index.wxml']['__stringify__']();
f_['wxs/wxs/stringify7e486c90.wxs'] = nv_require("p_wxs/wxs/stringify7e486c90.wxs");
var $gdm=function(path,global){
if(path&&e_[path]){
return function(env,dd,global){$gdmc=0;var root={"tag":"dd-page", "children":[]};
var main=e_[path].f;
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
main(env,{},root,global);
return root;
}
}
}
var $gwx=$gdm;
__ddAppCode__["pages/giftcard/package-list.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "pages/giftcard/package-list.wxml"] : $gwx("pages/giftcard/package-list.wxml");
__ddAppCode__["components/faq-title39ab4760/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/faq-title39ab4760/index.wxml"] : $gwx("components/faq-title39ab4760/index.wxml");
__ddAppCode__["components/package-questions936d56f6/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/package-questions936d56f6/index.wxml"] : $gwx("components/package-questions936d56f6/index.wxml");
__ddAppCode__["components/bill-circle-loading2622f42b/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/bill-circle-loading2622f42b/index.wxml"] : $gwx("components/bill-circle-loading2622f42b/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/loading/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/loading/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/loading/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/button/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/button/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/button/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/cell-group/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/cell-group/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/cell-group/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/cell/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/cell/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/cell/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/field/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/field/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/field/index.wxml");
__ddAppCode__["components/vant/weapp05bd39c0/transition/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant/weapp05bd39c0/transition/index.wxml"] : $gwx("components/vant/weapp05bd39c0/transition/index.wxml");
__ddAppCode__["components/vant/weapp05bd39c0/overlay/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant/weapp05bd39c0/overlay/index.wxml"] : $gwx("components/vant/weapp05bd39c0/overlay/index.wxml");
__ddAppCode__["components/price-popup1388dd35/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/price-popup1388dd35/index.wxml"] : $gwx("components/price-popup1388dd35/index.wxml");
__ddAppCode__["components/vant/weapp05bd39c0/info/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant/weapp05bd39c0/info/index.wxml"] : $gwx("components/vant/weapp05bd39c0/info/index.wxml");
__ddAppCode__["components/vant/weapp05bd39c0/icon/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant/weapp05bd39c0/icon/index.wxml"] : $gwx("components/vant/weapp05bd39c0/icon/index.wxml");
__ddAppCode__["components/package-cell4a6b6d6c/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/package-cell4a6b6d6c/index.wxml"] : $gwx("components/package-cell4a6b6d6c/index.wxml");
__ddAppCode__["components/vant/dist/sticky/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant/dist/sticky/index.wxml"] : $gwx("components/vant/dist/sticky/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/info/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/info/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/info/index.wxml");
__ddAppCode__["components/vant-weapp27f0c1f3/icon/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/vant-weapp27f0c1f3/icon/index.wxml"] : $gwx("components/vant-weapp27f0c1f3/icon/index.wxml");
__ddAppCode__["components/indexc0adbb64/index.wxml"] = __vd_version_info__.delayedGwx ? [$gwx, "components/indexc0adbb64/index.wxml"] : $gwx("components/indexc0adbb64/index.wxml");
