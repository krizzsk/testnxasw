void function() {
  

  

  

  Foundation && Foundation.refreshDDConfig && Foundation.refreshDDConfig({
  "pages": [
    "pages/index",
    "pages/webview",
    "pages/bill/list",
    "pages/bill/payDetail",
    "pages/giftcard/card-list",
    "pages/giftcard/package-list",
    "pages/giftcard/index",
    "pages/giftcard/detail"
  ],
  "global": {
    "window": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show"
    }
  },
  "subpackagesDir": {
    "__APP__": "app"
  },
  "subpackages": [],
  "subPackages": [],
  "entryPagePath": "pages/index",
  "page": {
    "pages/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexd1c1497a/index"
      }
    },
    "pages/webview": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {}
    },
    "pages/bill/list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/listb1a650be/index",
        "bill-list-card": "/components/bill-list-card2797778c/index",
        "bill-list-tab": "/components/bill-list-tab95b7a2f2/index",
        "bill-toast": "/components/bill-toastf1e12458/index",
        "bill-popup-bottom": "/components/bill-popup-bottom0899930d/index",
        "bill-picker": "/components/bill-picker22b74baf/index",
        "bill-list-cell": "/components/bill-list-cell1d37e644/index",
        "bill-bebeing": "/components/bill-bebeing0acb3a09/index"
      }
    },
    "pages/bill/payDetail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexd1c1497a/index",
        "bill-popup": "/components/bill-popup52ac7dd9/index",
        "bill-button": "/components/bill-buttone6670f5a/index",
        "bill-toast": "/components/bill-toastf1e12458/index",
        "bill-popup-bottom": "/components/bill-popup-bottom0899930d/index",
        "bill-circle-loading": "/components/bill-circle-loadingf4ea8c40/index",
        "van-icon": "/components/vant/weapp6f85d64b/icon/index",
        "bill-activity-popup": "/components/bill-activity-popup406eece2/index"
      }
    },
    "pages/giftcard/card-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/listb1a650be/index",
        "bill-bebeing": "/components/bill-bebeing0acb3a09/index"
      }
    },
    "pages/giftcard/package-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexd1c1497a/index",
        "package-cell": "/components/package-cell11b667b5/index",
        "van-icon": "/components/vant/weapp6f85d64b/icon/index",
        "price-popup": "/components/price-popup7a8c752c/index",
        "bill-popup-bottom": "/components/bill-popup-bottom0899930d/index",
        "bill-circle-loading": "/components/bill-circle-loadingf4ea8c40/index",
        "info-entry-popup": "/components/info-entry-popupec5321c4/index",
        "package-questions": "/components/package-questions3ab0f7a0/index",
        "faq-title": "/components/faq-title21fd520b/index",
        "ibg-buttom": "/components/ibg-button58b119dd/index"
      }
    },
    "pages/giftcard/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "layout-list": "/components/listb1a650be/index",
        "gift-card-tips": "/components/gift-card-tips34cf5838/index",
        "bill-popup-bottom": "/components/bill-popup-bottom0899930d/index",
        "van-icon": "/components/vant/weapp6f85d64b/icon/index",
        "api-loading": "/components/api-loadingf923536a/index"
      }
    },
    "pages/giftcard/detail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-sticky": "/components/vant/dist/sticky/index",
        "bill-toast": "/components/bill-toastf1e12458/index",
        "van-icon": "/components/vant/weapp6f85d64b/icon/index",
        "nav-bar": "/components/indexd1c1497a/index"
      }
    }
  }
});

}();
